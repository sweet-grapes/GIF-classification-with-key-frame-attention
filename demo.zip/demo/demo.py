import argparse
import os
import torch
import numpy as np
import imageio
import torchvision.transforms as T
from network.resnet50_attention import DCEHAAModel
import pyglet

INDEX_CLASS_MAP = {
    0: 'weightlifting',
    1: 'ping-pong',
    2: 'cloud',
    3: 'hamster',
    4: 'penguin',
    5: 'gymnastics',
    6: 'aerobics',
    7: 'rabbit',
    8: 'ice',
    9: 'glacier',
    10: 'surfing',
    11: 'aurora-borealis',
    12: 'hiromi',
    13: 'chihuahua',
    14: 'husky',
    15: 'elephant',
    16: 'shoot',
    17: 'racoon',
    18: 'duck',
    19: 'mountain',
    20: 'goat',
    21: 'sailboat',
    22: 'handball',
    23: 'boxing',
    24: 'volleyball',
    25: 'sunrise',
    26: 'sunset',
    27: 'starry-sky',
    28: 'moon',
    29: 'squirrel',
    30: 'corgi',
    31: 'baseball',
    32: 'forest',
    33: 'plant',
    34: 'desert',
    35: 'teddy',
    36: 'ocean',
    37: 'beach',
    38: 'sea-se',
    39: 'swimming',
    40: 'lake',
    41: 'skateboard',
    42: 'skiing',
    43: 'waterfall',
    44: 'panda',
    45: 'lion',
    46: 'pig',
    47: 'cat',
    48: 'monkey',
    49: 'yoga',
    50: 'fall',
    51: 'basketball',
    52: 'tennis',
    53: 'badminton',
    54: 'tiger',
    55: 'bicycle',
    56: 'grassland',
    57: 'kangaroo',
    58: 'porcupine',
    59: 'football',
    60: 'run',
    61: 'hurdle',
    62: 'skydiving',
    63: 'diving',
    64: 'dancing',
    65: 'giraffe',
    66: 'snow-mountain',
    67: 'ferret',
    68: 'fog',
    69: 'fish',
    70: 'bird',
    71: 'tornado',
    72: 'totoro'}
# CLASS_INDEX_MAP = {v: k for k, v in INDEX_CLASS_MAP.items()}


def load_gif(args):
    MEAN = (0.485, 0.456, 0.406)
    STD = (0.229, 0.224, 0.225)
    gif_name = os.path.basename(args.gif_path)
    label = gif_name[:-4]

    frames = []
    for i in imageio.get_reader(args.gif_path):
        if len(i.shape) == 2:
            i = np.stack([i] * 3, axis=-1)
        frames.append(i[:, :, :3])
    frames = np.array(frames)
    num_frames = frames.shape[0]
    if num_frames > args.num_frames:
        # sample some frames throughout the sequence
        frames_idx = np.round(np.linspace(0, num_frames - 1, args.num_frames)).astype(np.uint)
        frames = frames[frames_idx]
        select_frames_index = frames_idx.tolist()
    else:
        # pad with edge
        num_frames_delta = args.num_frames - num_frames
        frames = np.pad(frames,
                        pad_width=[(num_frames_delta // 2, num_frames_delta - num_frames_delta // 2), (0, 0), (0, 0),
                                   (0, 0)], mode='edge')
        select_frames_index = list(range(0, args.num_frames))

    transform = T.Compose([T.ToPILImage(), T.Resize((224, 224)), T.ToTensor(), T.Normalize(MEAN, STD)])
    frames = torch.stack([transform(i) for i in frames])
    return frames, label, select_frames_index


def main():
    parser = argparse.ArgumentParser(description='GIF Classification')
    parser.add_argument('gif_path', type=str, help='path to GIF')
    parser.add_argument('--num_frames', type=int, default=8)
    args = parser.parse_args()

    # process gif
    gif_frames, gif_label, select_frames_index = load_gif(args)

    # load pretrained model
    net = DCEHAAModel(backbone='resnet50', num_frames=args.num_frames)
    state_dict = torch.load('pretrained.pth')
    net.load_state_dict(state_dict)
    net.eval()
    # add batch dim
    gif_frames = gif_frames[None, ...]
    pred_scores, att = net(gif_frames)
    pred_scores = pred_scores[0]
    pred_index = torch.argmax(pred_scores).item()
    pred_label = INDEX_CLASS_MAP[pred_index]
    print("The ground truth of the animated GIF: {}".format(gif_label))
    print("The prediction category of the animated GIF: {}".format(pred_label))
    print("The index of {0} frames selected from the animated GIF is {1}.".format(args.num_frames, select_frames_index))
    print("The weight of {0} frames selected from the animated GIF is {1}.".format(args.num_frames, att[0].detach().numpy().tolist()))
    # display the animated GIF
    animation = pyglet.resource.animation(args.gif_path)
    sprite = pyglet.sprite.Sprite(animation)

    # create a window and set it to the image size
    win = pyglet.window.Window(width=sprite.width, height=sprite.height)

    # set window background color = r, g, b, alpha
    # each value from 0.0 to 1.0
    green = 0, 1, 0, 1
    pyglet.gl.glClearColor(*green)

    @win.event
    def on_draw():
        win.clear()
        sprite.draw()

    pyglet.app.run()


if __name__ == '__main__':
    main()