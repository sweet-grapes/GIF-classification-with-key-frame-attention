The GIF samples, network, and pre-training model needed for the demo.


requirements:
pip install numpy imageio pyglet
pip install torch==1.7.1+cu101 torchvision==0.8.2+cu101 torchaudio===0.7.2 -f https://download.pytorch.org/whl/torch_stable.html

run demo:
python demo.py GIF_PATH [--num_frames N]

for example: python demo.py examples/panda.gif
